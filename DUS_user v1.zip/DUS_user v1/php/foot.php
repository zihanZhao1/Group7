
<div class="container-fluid no-border">
    <div id="footer" class="row-fluid">
        <div class="span12">
            <ul class="nav nav-pills">
                <li><a href='https://www.dur.ac.uk/contactform2/?pageid=59579'>Comments &amp; Questions</a></li>
                <li><a href='https://www.dur.ac.uk/about/terms/'>Disclaimer</a></li>
                <li><a href='https://www.dur.ac.uk/about/trading_name/'>Trading Name</a></li>
                <li><a href="https://www.dur.ac.uk/about/cookies/">Cookie usage policy</a></li>
                <li><a href="https://www.dur.ac.uk/ig/dp/privacy/">Privacy Notices</a></li>
                <li class="status">Team Durham is part of Durham University. &nbsp; Updated: 10th May 2019</li>
            </ul>

            <script type="text/javascript">
                var _gaq = _gaq || [];
                if (typeof MAP_ON_PAGE !== 'undefined' && MAP_ON_PAGE) {
                    document.write('<' + 'script src="//maps.google.com/maps/api/js?sensor=false"' + ' type="text/javascript"><' + '/script>');
                }
            </script>

            <!--            <script type="text/javascript" src="//www.dur.ac.uk/js/scripts.min.js"></script>-->
            <noscript>
                <iframe src="//www.googletagmanager.com/ns.html?id=GTM-W9Q3S4"
                        height="0" width="0" style="display:none;visibility:hidden"></iframe>
            </noscript>
            <script>(function (w, d, s, l, i) {
                w[l] = w[l] || [];
                w[l].push({
                    'gtm.start':
                        new Date().getTime(), event: 'gtm.js'
                });
                var f = d.getElementsByTagName(s)[0],
                    j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : '';
                j.async = true;
                j.src =
                    '//www.googletagmanager.com/gtm.js?id=' + i + dl;
                f.parentNode.insertBefore(j, f);
            })(window, document, 'script', 'dataLayer', 'GTM-W9Q3S4');</script>
        </div>
    </div>
</div>